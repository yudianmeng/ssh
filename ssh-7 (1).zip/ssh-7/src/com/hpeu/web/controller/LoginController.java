package com.hpeu.web.controller;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.hpeu.bean.User;
import com.hpeu.config.Config;
import com.hpeu.service.UserService;
import com.hpeu.util.ValidateUtil;

/**
 * 登录和退出控制器类
 * 
 * @author 姚臣伟
 */
@Controller
@RequestMapping("/admin")
public class LoginController {
	@Resource(name = "userService")
	private UserService userService;
	
	// 登录
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public String login(HttpServletRequest request,
			@RequestParam(value="account",required=true) String account,
			@RequestParam(value="password",required=true) String password,
			@RequestParam(value="code",required=true) String code,
			Map<String, Object> map) {
		
		// 验证数据有有效性
		if (!ValidateUtil.validateString(account, Config.ACCOUNTREG)) {
			map.put("accountMsg", "账号不对，必须是6~16个字母、数字或下划线组成。");
			map.put("account", account);
		}
		if (!ValidateUtil.validateString(password, Config.PASSWORDREG)) {
			map.put("passwordMsg", "密码不对，必须是6~16个字母、数字或下划线组成。");
		}
		if (!ValidateUtil.validateString(code, Config.CODEREG)) {
			map.put("codeMsg", "验证码不对，由5个字母或数字组成。");
			map.put("code", code);
		}
		if (!map.isEmpty()) {
			return "login";
		}
		
		HttpSession session = request.getSession();
		// 从Session对象中获取验证码数据
		String sessionCode = (String)session.getAttribute("code");
		if (code.equalsIgnoreCase(sessionCode)) {
			// 根据账号和密码查询用户是否存在
			User user = userService.login(account, password);
			if (null != user) {
				// 登录成功后，把用户放到session对象中
				session.setAttribute("u", user);
				// 登录成功后把验证码从session对象中去掉
				session.removeAttribute("code");
				// 重定向到后台管理界面
				return "redirect:/admin/index.jsp";
			} else {
				map.put("accountMsg", "账名或密码错误。");
				map.put("account", account);
				map.put("code", code);
				return "login";
			}
		} else {
			map.put("codeMsg", "验证码错误。");
			map.put("account", account);
			map.put("code", code);
			return "login";
		}
	}
	
	// 退出
	@RequestMapping(value="/loginout",method=RequestMethod.GET)
	public String loginOut(HttpServletRequest request) {
		// 第一步：创建Session对象
		HttpSession session = request.getSession();
		
		// 第二步：删除Session对象中的数据
		session.invalidate();
		
		// 第三步：重定向到登录页面
		return "redirect:/admin/login.jsp";
	}
}
