package com.hpeu.web.controller;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.hpeu.bean.Department;
import com.hpeu.bean.Employee;
import com.hpeu.config.Config;
import com.hpeu.service.DepartmentService;
import com.hpeu.service.EmployeeService;
import com.hpeu.util.PaginationUtil;
import com.hpeu.util.ValidateUtil;

/**
 * 员工控制器类
 * 
 * @author 姚臣伟
 */
@Controller
@RequestMapping("/admin")
public class EmployeeController {
	@Resource(name="employeeService")
	private EmployeeService employeeService;
	@Resource(name="departmentService")
	private DepartmentService departmentService;
	
	// 列表
	@RequestMapping("/employeeList")
	public String list(@RequestParam(value="page",required=false) String pageStr,
			@RequestParam(value="did",required=false) String didStr,
			Map<String, Object> map) {
		
		int page = ValidateUtil.stringToInt(pageStr);
		if (page <= 0) {
			page = 1;
		}
		
		List<Department> departs = departmentService.findDepartments();
		// 把查询到的数据放到map对象中
		map.put("departs", departs);
		
		// 获取部门编号
		int departId = ValidateUtil.stringToInt(didStr);
		PaginationUtil<Employee> emps = null;
		if (departId > 0) {
			emps = employeeService.findEmployeesByPage(page, Config.USER_PAGE_SIZE, departId);
		} else {
			emps = employeeService.findEmployeesByPage(page, Config.USER_PAGE_SIZE);
		}
		
		map.put("emps", emps);
		map.put("departId", departId);
		
		return "employee/list";
	}
	
	// 转到添加
	@RequestMapping(value="/addEmployee",method=RequestMethod.GET)
	public String add(Map<String, Object> map) {
		List<Department> departs = departmentService.findDepartments();
		map.put("departs", departs);
		return "employee/add";
	}
	
	// 处理添加
	@RequestMapping(value="/addEmployeeHandler",method=RequestMethod.POST)
	public String add(Employee employee, @RequestParam("did") String didStr) {
		
		// 设置入职时间
		employee.setJoinTime(new Date());
		
		// 获取部门编号
		int departId = ValidateUtil.stringToInt(didStr);
		Department depart = departmentService.findDepartmentById(departId);
		// 设置员工与部门的关联关系
		employee.setDepart(depart);
		
		// 添加员工数据
		employeeService.save(employee);
		
		return "redirect:/admin/employeeList";
	}
	
	// 转到修改
	@RequestMapping(value="/editEmployee", method=RequestMethod.GET)
	public String edit(@RequestParam("id") String idStr,
			@RequestParam(value="page",required=false) String pageStr,
			Map<String, Object> map) {
		
		List<Department> departs = departmentService.findDepartments();
		map.put("departs", departs);
		
		// 把字符串的ID转换数字ID
		int id = ValidateUtil.stringToInt(idStr);
		int page = ValidateUtil.stringToInt(pageStr);
		
		Employee emp = employeeService.findEmployeeById(id);
		map.put("emp", emp);
		
		map.put("page", page);
		
		return "employee/edit";
	}
	
	// 处理修改
	@RequestMapping(value="/editEmployeeHandler",method=RequestMethod.POST)
	public String edit(Employee employee,
			@RequestParam("did") String didStr,
			@RequestParam(value="page",required=false) String pageStr) {
		
		Employee em = employeeService.findEmployeeById(employee.getId());
		// 设置入职时间
		employee.setJoinTime(em.getJoinTime());
		
		// 获取部门编号
		int departId = ValidateUtil.stringToInt(didStr);
		
		Department depart = departmentService.findDepartmentById(departId);
		// 设置员工与部门的关联关系
		employee.setDepart(depart);
		
		// 添加员工数据
		employeeService.update(employee);
		
		return "redirect:/admin/employeeList?page="+pageStr;
	}
	
	// 删除
	@RequestMapping(value="/deleteEmployee",method=RequestMethod.GET)
	public String del(@RequestParam("id") String idStr,
			@RequestParam(value="page",required=false) String pageStr) {
		// 把字符串的ID转换数字ID
		int id = ValidateUtil.stringToInt(idStr);
		int page = ValidateUtil.stringToInt(pageStr);
		
		// 根据用户编号查询用户信息
		employeeService.delete(id);
		return "redirect:/admin/employeeList?page=" + page;
	}
	
}
