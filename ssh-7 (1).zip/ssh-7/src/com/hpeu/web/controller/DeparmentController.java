package com.hpeu.web.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.hpeu.bean.Department;
import com.hpeu.service.DepartmentService;
import com.hpeu.util.ValidateUtil;

/**
 * 部门控制器类
 * 
 * @author 姚臣伟
 */
@Controller
@RequestMapping("/admin")
public class DeparmentController {
	@Resource(name="departmentService")
	private DepartmentService departmentService;
	
	// 列表
	@RequestMapping("/departList")
	public String list(@RequestParam(value="page",required=false) String pageStr,
			Map<String, Object> map) {
		
		int page = ValidateUtil.stringToInt(pageStr);
		if (page <= 0) {
			page = 1;
		}
		List<Department> departs = departmentService.findDepartments();
		// 把查询到的数据放到request对象中
		map.put("departs", departs);
		
		return "depart/list";
	}
	
	// 添加
	@RequestMapping(value="/addDepartHandler",method=RequestMethod.POST)
	public String add(Department department) {
		// 添加部门数据
		departmentService.save(department);
		
		return "redirect:/admin/departList";
	}
	
	// 转到修改页
	@RequestMapping(value="/editDepart",method=RequestMethod.GET)
	public String edit(@RequestParam(value="id",required=true) String idStr,
			Map<String, Object> map) {
		// 把字符串的ID转换数字ID
		int id = ValidateUtil.stringToInt(idStr);
		// 根据部门编号查询部门信息
		Department depart = departmentService.findDepartmentById(id);
		// 把查询到的部门信息放入到map对象中
		map.put("depart", depart);
		return "depart/edit";
	}
	
	// 处理修改
	@RequestMapping(value="/editDepartHandler", method=RequestMethod.POST)
	public String edit(Department department) {
		// 执行部门信息修改
		departmentService.update(department);
		
		return "redirect:/admin/departList";
	}
	
	// 删除
	@RequestMapping(value="/deleteDepart", method=RequestMethod.GET)
	public String del(@RequestParam("id") String idStr) {
		// 把字符串的ID转换数字ID
		int id = ValidateUtil.stringToInt(idStr);
		
		// 根据用户编号查询用户信息
		Department depart = departmentService.findDepartmentById(id);
		if (null != depart) {
			// 删除信息
			departmentService.delete(depart);
		}
		return "redirect:/admin/departList";
	}
	
}
